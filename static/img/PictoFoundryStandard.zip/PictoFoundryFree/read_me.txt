Picto Foundry v1.1
website: http://pictofoundry.com & http://34orange.com
twitter: @pictofoundry, @34Orange, @coryshoaf
created by: Cory Shoaf of 34 Orange LLC


---

Thanks for downloading Picto Foundry (Free)!

LICENSE: 
You're free to use these products for all projects (commercial and non-commercial) pertaining to you, your company, and your clients. You may edit and remix these products, but may NOT resell or rebrand. 

ATTRIBUTION: 
If you use these free products for all projects pertaining to you, your company, and your clients, be sure to contribute by linking to Picto Foundry from your twitter, website, Facebook, blogpost, etc. Picto Foundry thanks you. 

QUESTIONS:
Contact us at support@pictofoundry.com with questions or comments on payments or licensing issues.



Picto Foundry and Picto Foundry Pro are products of 34 Orange LLC
 